﻿namespace CIS153_FinalProject_Group2
{
    partial class TwoPlayerC4Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Col6Slot = new System.Windows.Forms.Button();
            this.btn_Col5Slot = new System.Windows.Forms.Button();
            this.btn_Col4Slot = new System.Windows.Forms.Button();
            this.btn_Col3Slot = new System.Windows.Forms.Button();
            this.btn_Col2Slot = new System.Windows.Forms.Button();
            this.btn_Col1Slot = new System.Windows.Forms.Button();
            this.btn_Col0Slot = new System.Windows.Forms.Button();
            this.btn_56 = new System.Windows.Forms.Button();
            this.btn_55 = new System.Windows.Forms.Button();
            this.btn_54 = new System.Windows.Forms.Button();
            this.btn_53 = new System.Windows.Forms.Button();
            this.btn_52 = new System.Windows.Forms.Button();
            this.btn_51 = new System.Windows.Forms.Button();
            this.btn_50 = new System.Windows.Forms.Button();
            this.btn_46 = new System.Windows.Forms.Button();
            this.btn_45 = new System.Windows.Forms.Button();
            this.btn_44 = new System.Windows.Forms.Button();
            this.btn_43 = new System.Windows.Forms.Button();
            this.btn_42 = new System.Windows.Forms.Button();
            this.btn_41 = new System.Windows.Forms.Button();
            this.btn_40 = new System.Windows.Forms.Button();
            this.btn_36 = new System.Windows.Forms.Button();
            this.btn_35 = new System.Windows.Forms.Button();
            this.btn_34 = new System.Windows.Forms.Button();
            this.btn_33 = new System.Windows.Forms.Button();
            this.btn_32 = new System.Windows.Forms.Button();
            this.btn_31 = new System.Windows.Forms.Button();
            this.btn_30 = new System.Windows.Forms.Button();
            this.btn_26 = new System.Windows.Forms.Button();
            this.btn_25 = new System.Windows.Forms.Button();
            this.btn_24 = new System.Windows.Forms.Button();
            this.btn_23 = new System.Windows.Forms.Button();
            this.btn_22 = new System.Windows.Forms.Button();
            this.btn_21 = new System.Windows.Forms.Button();
            this.btn_20 = new System.Windows.Forms.Button();
            this.btn_16 = new System.Windows.Forms.Button();
            this.btn_15 = new System.Windows.Forms.Button();
            this.btn_14 = new System.Windows.Forms.Button();
            this.btn_13 = new System.Windows.Forms.Button();
            this.btn_12 = new System.Windows.Forms.Button();
            this.btn_11 = new System.Windows.Forms.Button();
            this.btn_10 = new System.Windows.Forms.Button();
            this.btn_06 = new System.Windows.Forms.Button();
            this.btn_05 = new System.Windows.Forms.Button();
            this.btn_04 = new System.Windows.Forms.Button();
            this.btn_03 = new System.Windows.Forms.Button();
            this.btn_02 = new System.Windows.Forms.Button();
            this.btn_01 = new System.Windows.Forms.Button();
            this.btn_00 = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.btn_loadMainScreen = new System.Windows.Forms.Button();
            this.txt_playerTurn = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_Col6Slot
            // 
            this.btn_Col6Slot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_Col6Slot.Location = new System.Drawing.Point(440, 33);
            this.btn_Col6Slot.Name = "btn_Col6Slot";
            this.btn_Col6Slot.Size = new System.Drawing.Size(59, 59);
            this.btn_Col6Slot.TabIndex = 152;
            this.btn_Col6Slot.UseVisualStyleBackColor = false;
            this.btn_Col6Slot.Click += new System.EventHandler(this.btn_Col6Slot_Click);
            this.btn_Col6Slot.MouseLeave += new System.EventHandler(this.btn_Col6Slot_MouseLeave);
            this.btn_Col6Slot.MouseHover += new System.EventHandler(this.btn_Col6Slot_MouseHover);
            // 
            // btn_Col5Slot
            // 
            this.btn_Col5Slot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_Col5Slot.Location = new System.Drawing.Point(375, 33);
            this.btn_Col5Slot.Name = "btn_Col5Slot";
            this.btn_Col5Slot.Size = new System.Drawing.Size(59, 59);
            this.btn_Col5Slot.TabIndex = 151;
            this.btn_Col5Slot.UseVisualStyleBackColor = false;
            this.btn_Col5Slot.Click += new System.EventHandler(this.btn_Col5Slot_Click);
            this.btn_Col5Slot.MouseLeave += new System.EventHandler(this.btn_Col5Slot_MouseLeave);
            this.btn_Col5Slot.MouseHover += new System.EventHandler(this.btn_Col5Slot_MouseHover);
            // 
            // btn_Col4Slot
            // 
            this.btn_Col4Slot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_Col4Slot.Location = new System.Drawing.Point(310, 33);
            this.btn_Col4Slot.Name = "btn_Col4Slot";
            this.btn_Col4Slot.Size = new System.Drawing.Size(59, 59);
            this.btn_Col4Slot.TabIndex = 150;
            this.btn_Col4Slot.UseVisualStyleBackColor = false;
            this.btn_Col4Slot.Click += new System.EventHandler(this.btn_Col4Slot_Click);
            this.btn_Col4Slot.MouseLeave += new System.EventHandler(this.btn_Col4Slot_MouseLeave);
            this.btn_Col4Slot.MouseHover += new System.EventHandler(this.btn_Col4Slot_MouseHover);
            // 
            // btn_Col3Slot
            // 
            this.btn_Col3Slot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_Col3Slot.Location = new System.Drawing.Point(245, 33);
            this.btn_Col3Slot.Name = "btn_Col3Slot";
            this.btn_Col3Slot.Size = new System.Drawing.Size(59, 59);
            this.btn_Col3Slot.TabIndex = 149;
            this.btn_Col3Slot.UseVisualStyleBackColor = false;
            this.btn_Col3Slot.Click += new System.EventHandler(this.btn_Col3Slot_Click);
            this.btn_Col3Slot.MouseLeave += new System.EventHandler(this.btn_Col3Slot_MouseLeave);
            this.btn_Col3Slot.MouseHover += new System.EventHandler(this.btn_Col3Slot_MouseHover);
            // 
            // btn_Col2Slot
            // 
            this.btn_Col2Slot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_Col2Slot.Location = new System.Drawing.Point(180, 33);
            this.btn_Col2Slot.Name = "btn_Col2Slot";
            this.btn_Col2Slot.Size = new System.Drawing.Size(59, 59);
            this.btn_Col2Slot.TabIndex = 148;
            this.btn_Col2Slot.UseVisualStyleBackColor = false;
            this.btn_Col2Slot.Click += new System.EventHandler(this.btn_Col2Slot_Click);
            this.btn_Col2Slot.MouseLeave += new System.EventHandler(this.btn_Col2Slot_MouseLeave);
            this.btn_Col2Slot.MouseHover += new System.EventHandler(this.btn_Col2Slot_MouseHover);
            // 
            // btn_Col1Slot
            // 
            this.btn_Col1Slot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_Col1Slot.Location = new System.Drawing.Point(115, 33);
            this.btn_Col1Slot.Name = "btn_Col1Slot";
            this.btn_Col1Slot.Size = new System.Drawing.Size(59, 59);
            this.btn_Col1Slot.TabIndex = 147;
            this.btn_Col1Slot.UseVisualStyleBackColor = false;
            this.btn_Col1Slot.Click += new System.EventHandler(this.btn_Col1Slot_Click);
            this.btn_Col1Slot.MouseLeave += new System.EventHandler(this.btn_Col1Slot_MouseLeave);
            this.btn_Col1Slot.MouseHover += new System.EventHandler(this.btn_Col1Slot_MouseHover);
            // 
            // btn_Col0Slot
            // 
            this.btn_Col0Slot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_Col0Slot.Location = new System.Drawing.Point(50, 33);
            this.btn_Col0Slot.Name = "btn_Col0Slot";
            this.btn_Col0Slot.Size = new System.Drawing.Size(59, 59);
            this.btn_Col0Slot.TabIndex = 146;
            this.btn_Col0Slot.UseVisualStyleBackColor = false;
            this.btn_Col0Slot.Click += new System.EventHandler(this.btn_Col0Slot_Click);
            this.btn_Col0Slot.MouseLeave += new System.EventHandler(this.btn_Col0Slot_MouseLeave);
            this.btn_Col0Slot.MouseHover += new System.EventHandler(this.btn_Col0Slot_MouseHover);
            // 
            // btn_56
            // 
            this.btn_56.BackColor = System.Drawing.Color.White;
            this.btn_56.Enabled = false;
            this.btn_56.Location = new System.Drawing.Point(440, 413);
            this.btn_56.Name = "btn_56";
            this.btn_56.Size = new System.Drawing.Size(59, 59);
            this.btn_56.TabIndex = 145;
            this.btn_56.UseVisualStyleBackColor = false;
            // 
            // btn_55
            // 
            this.btn_55.BackColor = System.Drawing.Color.White;
            this.btn_55.Enabled = false;
            this.btn_55.Location = new System.Drawing.Point(375, 413);
            this.btn_55.Name = "btn_55";
            this.btn_55.Size = new System.Drawing.Size(59, 59);
            this.btn_55.TabIndex = 144;
            this.btn_55.UseVisualStyleBackColor = false;
            // 
            // btn_54
            // 
            this.btn_54.BackColor = System.Drawing.Color.White;
            this.btn_54.Enabled = false;
            this.btn_54.Location = new System.Drawing.Point(310, 413);
            this.btn_54.Name = "btn_54";
            this.btn_54.Size = new System.Drawing.Size(59, 59);
            this.btn_54.TabIndex = 143;
            this.btn_54.UseVisualStyleBackColor = false;
            // 
            // btn_53
            // 
            this.btn_53.BackColor = System.Drawing.Color.White;
            this.btn_53.Enabled = false;
            this.btn_53.Location = new System.Drawing.Point(245, 413);
            this.btn_53.Name = "btn_53";
            this.btn_53.Size = new System.Drawing.Size(59, 59);
            this.btn_53.TabIndex = 142;
            this.btn_53.UseVisualStyleBackColor = false;
            // 
            // btn_52
            // 
            this.btn_52.BackColor = System.Drawing.Color.White;
            this.btn_52.Enabled = false;
            this.btn_52.Location = new System.Drawing.Point(180, 413);
            this.btn_52.Name = "btn_52";
            this.btn_52.Size = new System.Drawing.Size(59, 59);
            this.btn_52.TabIndex = 141;
            this.btn_52.UseVisualStyleBackColor = false;
            // 
            // btn_51
            // 
            this.btn_51.BackColor = System.Drawing.Color.White;
            this.btn_51.Enabled = false;
            this.btn_51.Location = new System.Drawing.Point(115, 413);
            this.btn_51.Name = "btn_51";
            this.btn_51.Size = new System.Drawing.Size(59, 59);
            this.btn_51.TabIndex = 140;
            this.btn_51.UseVisualStyleBackColor = false;
            // 
            // btn_50
            // 
            this.btn_50.BackColor = System.Drawing.Color.White;
            this.btn_50.Enabled = false;
            this.btn_50.Location = new System.Drawing.Point(50, 413);
            this.btn_50.Name = "btn_50";
            this.btn_50.Size = new System.Drawing.Size(59, 59);
            this.btn_50.TabIndex = 139;
            this.btn_50.UseVisualStyleBackColor = false;
            // 
            // btn_46
            // 
            this.btn_46.BackColor = System.Drawing.Color.White;
            this.btn_46.Enabled = false;
            this.btn_46.Location = new System.Drawing.Point(440, 350);
            this.btn_46.Name = "btn_46";
            this.btn_46.Size = new System.Drawing.Size(59, 59);
            this.btn_46.TabIndex = 138;
            this.btn_46.UseVisualStyleBackColor = false;
            // 
            // btn_45
            // 
            this.btn_45.BackColor = System.Drawing.Color.White;
            this.btn_45.Enabled = false;
            this.btn_45.Location = new System.Drawing.Point(375, 350);
            this.btn_45.Name = "btn_45";
            this.btn_45.Size = new System.Drawing.Size(59, 59);
            this.btn_45.TabIndex = 137;
            this.btn_45.UseVisualStyleBackColor = false;
            // 
            // btn_44
            // 
            this.btn_44.BackColor = System.Drawing.Color.White;
            this.btn_44.Enabled = false;
            this.btn_44.Location = new System.Drawing.Point(310, 350);
            this.btn_44.Name = "btn_44";
            this.btn_44.Size = new System.Drawing.Size(59, 59);
            this.btn_44.TabIndex = 136;
            this.btn_44.UseVisualStyleBackColor = false;
            // 
            // btn_43
            // 
            this.btn_43.BackColor = System.Drawing.Color.White;
            this.btn_43.Enabled = false;
            this.btn_43.Location = new System.Drawing.Point(245, 350);
            this.btn_43.Name = "btn_43";
            this.btn_43.Size = new System.Drawing.Size(59, 59);
            this.btn_43.TabIndex = 135;
            this.btn_43.UseVisualStyleBackColor = false;
            // 
            // btn_42
            // 
            this.btn_42.BackColor = System.Drawing.Color.White;
            this.btn_42.Enabled = false;
            this.btn_42.Location = new System.Drawing.Point(180, 350);
            this.btn_42.Name = "btn_42";
            this.btn_42.Size = new System.Drawing.Size(59, 59);
            this.btn_42.TabIndex = 134;
            this.btn_42.UseVisualStyleBackColor = false;
            // 
            // btn_41
            // 
            this.btn_41.BackColor = System.Drawing.Color.White;
            this.btn_41.Enabled = false;
            this.btn_41.Location = new System.Drawing.Point(115, 350);
            this.btn_41.Name = "btn_41";
            this.btn_41.Size = new System.Drawing.Size(59, 59);
            this.btn_41.TabIndex = 133;
            this.btn_41.UseVisualStyleBackColor = false;
            // 
            // btn_40
            // 
            this.btn_40.BackColor = System.Drawing.Color.White;
            this.btn_40.Enabled = false;
            this.btn_40.Location = new System.Drawing.Point(50, 350);
            this.btn_40.Name = "btn_40";
            this.btn_40.Size = new System.Drawing.Size(59, 59);
            this.btn_40.TabIndex = 132;
            this.btn_40.UseVisualStyleBackColor = false;
            // 
            // btn_36
            // 
            this.btn_36.BackColor = System.Drawing.Color.White;
            this.btn_36.Enabled = false;
            this.btn_36.Location = new System.Drawing.Point(440, 287);
            this.btn_36.Name = "btn_36";
            this.btn_36.Size = new System.Drawing.Size(59, 59);
            this.btn_36.TabIndex = 131;
            this.btn_36.UseVisualStyleBackColor = false;
            // 
            // btn_35
            // 
            this.btn_35.BackColor = System.Drawing.Color.White;
            this.btn_35.Enabled = false;
            this.btn_35.Location = new System.Drawing.Point(375, 287);
            this.btn_35.Name = "btn_35";
            this.btn_35.Size = new System.Drawing.Size(59, 59);
            this.btn_35.TabIndex = 130;
            this.btn_35.UseVisualStyleBackColor = false;
            // 
            // btn_34
            // 
            this.btn_34.BackColor = System.Drawing.Color.White;
            this.btn_34.Enabled = false;
            this.btn_34.Location = new System.Drawing.Point(310, 287);
            this.btn_34.Name = "btn_34";
            this.btn_34.Size = new System.Drawing.Size(59, 59);
            this.btn_34.TabIndex = 129;
            this.btn_34.UseVisualStyleBackColor = false;
            // 
            // btn_33
            // 
            this.btn_33.BackColor = System.Drawing.Color.White;
            this.btn_33.Enabled = false;
            this.btn_33.Location = new System.Drawing.Point(245, 287);
            this.btn_33.Name = "btn_33";
            this.btn_33.Size = new System.Drawing.Size(59, 59);
            this.btn_33.TabIndex = 128;
            this.btn_33.UseVisualStyleBackColor = false;
            // 
            // btn_32
            // 
            this.btn_32.BackColor = System.Drawing.Color.White;
            this.btn_32.Enabled = false;
            this.btn_32.Location = new System.Drawing.Point(180, 287);
            this.btn_32.Name = "btn_32";
            this.btn_32.Size = new System.Drawing.Size(59, 59);
            this.btn_32.TabIndex = 127;
            this.btn_32.UseVisualStyleBackColor = false;
            // 
            // btn_31
            // 
            this.btn_31.BackColor = System.Drawing.Color.White;
            this.btn_31.Enabled = false;
            this.btn_31.Location = new System.Drawing.Point(115, 287);
            this.btn_31.Name = "btn_31";
            this.btn_31.Size = new System.Drawing.Size(59, 59);
            this.btn_31.TabIndex = 126;
            this.btn_31.UseVisualStyleBackColor = false;
            // 
            // btn_30
            // 
            this.btn_30.BackColor = System.Drawing.Color.White;
            this.btn_30.Enabled = false;
            this.btn_30.Location = new System.Drawing.Point(50, 287);
            this.btn_30.Name = "btn_30";
            this.btn_30.Size = new System.Drawing.Size(59, 59);
            this.btn_30.TabIndex = 125;
            this.btn_30.UseVisualStyleBackColor = false;
            // 
            // btn_26
            // 
            this.btn_26.BackColor = System.Drawing.Color.White;
            this.btn_26.Enabled = false;
            this.btn_26.Location = new System.Drawing.Point(440, 224);
            this.btn_26.Name = "btn_26";
            this.btn_26.Size = new System.Drawing.Size(59, 59);
            this.btn_26.TabIndex = 124;
            this.btn_26.UseVisualStyleBackColor = false;
            // 
            // btn_25
            // 
            this.btn_25.BackColor = System.Drawing.Color.White;
            this.btn_25.Enabled = false;
            this.btn_25.Location = new System.Drawing.Point(375, 224);
            this.btn_25.Name = "btn_25";
            this.btn_25.Size = new System.Drawing.Size(59, 59);
            this.btn_25.TabIndex = 123;
            this.btn_25.UseVisualStyleBackColor = false;
            // 
            // btn_24
            // 
            this.btn_24.BackColor = System.Drawing.Color.White;
            this.btn_24.Enabled = false;
            this.btn_24.Location = new System.Drawing.Point(310, 224);
            this.btn_24.Name = "btn_24";
            this.btn_24.Size = new System.Drawing.Size(59, 59);
            this.btn_24.TabIndex = 122;
            this.btn_24.UseVisualStyleBackColor = false;
            // 
            // btn_23
            // 
            this.btn_23.BackColor = System.Drawing.Color.White;
            this.btn_23.Enabled = false;
            this.btn_23.Location = new System.Drawing.Point(245, 224);
            this.btn_23.Name = "btn_23";
            this.btn_23.Size = new System.Drawing.Size(59, 59);
            this.btn_23.TabIndex = 121;
            this.btn_23.UseVisualStyleBackColor = false;
            // 
            // btn_22
            // 
            this.btn_22.BackColor = System.Drawing.Color.White;
            this.btn_22.Enabled = false;
            this.btn_22.Location = new System.Drawing.Point(180, 224);
            this.btn_22.Name = "btn_22";
            this.btn_22.Size = new System.Drawing.Size(59, 59);
            this.btn_22.TabIndex = 120;
            this.btn_22.UseVisualStyleBackColor = false;
            // 
            // btn_21
            // 
            this.btn_21.BackColor = System.Drawing.Color.White;
            this.btn_21.Enabled = false;
            this.btn_21.Location = new System.Drawing.Point(115, 224);
            this.btn_21.Name = "btn_21";
            this.btn_21.Size = new System.Drawing.Size(59, 59);
            this.btn_21.TabIndex = 119;
            this.btn_21.UseVisualStyleBackColor = false;
            // 
            // btn_20
            // 
            this.btn_20.BackColor = System.Drawing.Color.White;
            this.btn_20.Enabled = false;
            this.btn_20.Location = new System.Drawing.Point(50, 224);
            this.btn_20.Name = "btn_20";
            this.btn_20.Size = new System.Drawing.Size(59, 59);
            this.btn_20.TabIndex = 118;
            this.btn_20.UseVisualStyleBackColor = false;
            // 
            // btn_16
            // 
            this.btn_16.BackColor = System.Drawing.Color.White;
            this.btn_16.Enabled = false;
            this.btn_16.Location = new System.Drawing.Point(440, 161);
            this.btn_16.Name = "btn_16";
            this.btn_16.Size = new System.Drawing.Size(59, 59);
            this.btn_16.TabIndex = 117;
            this.btn_16.UseVisualStyleBackColor = false;
            // 
            // btn_15
            // 
            this.btn_15.BackColor = System.Drawing.Color.White;
            this.btn_15.Enabled = false;
            this.btn_15.Location = new System.Drawing.Point(375, 161);
            this.btn_15.Name = "btn_15";
            this.btn_15.Size = new System.Drawing.Size(59, 59);
            this.btn_15.TabIndex = 116;
            this.btn_15.UseVisualStyleBackColor = false;
            // 
            // btn_14
            // 
            this.btn_14.BackColor = System.Drawing.Color.White;
            this.btn_14.Enabled = false;
            this.btn_14.Location = new System.Drawing.Point(310, 161);
            this.btn_14.Name = "btn_14";
            this.btn_14.Size = new System.Drawing.Size(59, 59);
            this.btn_14.TabIndex = 115;
            this.btn_14.UseVisualStyleBackColor = false;
            // 
            // btn_13
            // 
            this.btn_13.BackColor = System.Drawing.Color.White;
            this.btn_13.Enabled = false;
            this.btn_13.Location = new System.Drawing.Point(245, 161);
            this.btn_13.Name = "btn_13";
            this.btn_13.Size = new System.Drawing.Size(59, 59);
            this.btn_13.TabIndex = 114;
            this.btn_13.UseVisualStyleBackColor = false;
            // 
            // btn_12
            // 
            this.btn_12.BackColor = System.Drawing.Color.White;
            this.btn_12.Enabled = false;
            this.btn_12.Location = new System.Drawing.Point(180, 161);
            this.btn_12.Name = "btn_12";
            this.btn_12.Size = new System.Drawing.Size(59, 59);
            this.btn_12.TabIndex = 113;
            this.btn_12.UseVisualStyleBackColor = false;
            // 
            // btn_11
            // 
            this.btn_11.BackColor = System.Drawing.Color.White;
            this.btn_11.Enabled = false;
            this.btn_11.Location = new System.Drawing.Point(115, 161);
            this.btn_11.Name = "btn_11";
            this.btn_11.Size = new System.Drawing.Size(59, 59);
            this.btn_11.TabIndex = 112;
            this.btn_11.UseVisualStyleBackColor = false;
            // 
            // btn_10
            // 
            this.btn_10.BackColor = System.Drawing.Color.White;
            this.btn_10.Enabled = false;
            this.btn_10.Location = new System.Drawing.Point(50, 161);
            this.btn_10.Name = "btn_10";
            this.btn_10.Size = new System.Drawing.Size(59, 59);
            this.btn_10.TabIndex = 111;
            this.btn_10.UseVisualStyleBackColor = false;
            // 
            // btn_06
            // 
            this.btn_06.BackColor = System.Drawing.Color.White;
            this.btn_06.Enabled = false;
            this.btn_06.Location = new System.Drawing.Point(440, 98);
            this.btn_06.Name = "btn_06";
            this.btn_06.Size = new System.Drawing.Size(59, 59);
            this.btn_06.TabIndex = 110;
            this.btn_06.UseVisualStyleBackColor = false;
            // 
            // btn_05
            // 
            this.btn_05.BackColor = System.Drawing.Color.White;
            this.btn_05.Enabled = false;
            this.btn_05.Location = new System.Drawing.Point(375, 98);
            this.btn_05.Name = "btn_05";
            this.btn_05.Size = new System.Drawing.Size(59, 59);
            this.btn_05.TabIndex = 109;
            this.btn_05.UseVisualStyleBackColor = false;
            // 
            // btn_04
            // 
            this.btn_04.BackColor = System.Drawing.Color.White;
            this.btn_04.Enabled = false;
            this.btn_04.Location = new System.Drawing.Point(310, 98);
            this.btn_04.Name = "btn_04";
            this.btn_04.Size = new System.Drawing.Size(59, 59);
            this.btn_04.TabIndex = 108;
            this.btn_04.UseVisualStyleBackColor = false;
            // 
            // btn_03
            // 
            this.btn_03.BackColor = System.Drawing.Color.White;
            this.btn_03.Enabled = false;
            this.btn_03.Location = new System.Drawing.Point(245, 98);
            this.btn_03.Name = "btn_03";
            this.btn_03.Size = new System.Drawing.Size(59, 59);
            this.btn_03.TabIndex = 107;
            this.btn_03.UseVisualStyleBackColor = false;
            // 
            // btn_02
            // 
            this.btn_02.BackColor = System.Drawing.Color.White;
            this.btn_02.Enabled = false;
            this.btn_02.Location = new System.Drawing.Point(180, 98);
            this.btn_02.Name = "btn_02";
            this.btn_02.Size = new System.Drawing.Size(59, 59);
            this.btn_02.TabIndex = 106;
            this.btn_02.UseVisualStyleBackColor = false;
            // 
            // btn_01
            // 
            this.btn_01.BackColor = System.Drawing.Color.White;
            this.btn_01.Enabled = false;
            this.btn_01.Location = new System.Drawing.Point(115, 98);
            this.btn_01.Name = "btn_01";
            this.btn_01.Size = new System.Drawing.Size(59, 59);
            this.btn_01.TabIndex = 105;
            this.btn_01.UseVisualStyleBackColor = false;
            // 
            // btn_00
            // 
            this.btn_00.BackColor = System.Drawing.Color.White;
            this.btn_00.Enabled = false;
            this.btn_00.Location = new System.Drawing.Point(50, 98);
            this.btn_00.Name = "btn_00";
            this.btn_00.Size = new System.Drawing.Size(59, 59);
            this.btn_00.TabIndex = 104;
            this.btn_00.UseVisualStyleBackColor = false;
            // 
            // btn_Exit
            // 
            this.btn_Exit.BackColor = System.Drawing.Color.Red;
            this.btn_Exit.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Exit.ForeColor = System.Drawing.Color.White;
            this.btn_Exit.Location = new System.Drawing.Point(375, 485);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(124, 37);
            this.btn_Exit.TabIndex = 103;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = false;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // btn_loadMainScreen
            // 
            this.btn_loadMainScreen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btn_loadMainScreen.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_loadMainScreen.ForeColor = System.Drawing.Color.White;
            this.btn_loadMainScreen.Location = new System.Drawing.Point(50, 485);
            this.btn_loadMainScreen.Name = "btn_loadMainScreen";
            this.btn_loadMainScreen.Size = new System.Drawing.Size(124, 37);
            this.btn_loadMainScreen.TabIndex = 102;
            this.btn_loadMainScreen.Text = "Main Screen";
            this.btn_loadMainScreen.UseVisualStyleBackColor = false;
            this.btn_loadMainScreen.Click += new System.EventHandler(this.btn_loadMainScreen_Click);
            // 
            // txt_playerTurn
            // 
            this.txt_playerTurn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txt_playerTurn.Cursor = System.Windows.Forms.Cursors.No;
            this.txt_playerTurn.Font = new System.Drawing.Font("Arial Narrow", 19F, System.Drawing.FontStyle.Bold);
            this.txt_playerTurn.ForeColor = System.Drawing.Color.White;
            this.txt_playerTurn.Location = new System.Drawing.Point(180, 485);
            this.txt_playerTurn.Name = "txt_playerTurn";
            this.txt_playerTurn.ReadOnly = true;
            this.txt_playerTurn.Size = new System.Drawing.Size(189, 37);
            this.txt_playerTurn.TabIndex = 153;
            this.txt_playerTurn.Text = "Turn: Player 1";
            this.txt_playerTurn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TwoPlayerC4Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.ClientSize = new System.Drawing.Size(543, 551);
            this.Controls.Add(this.txt_playerTurn);
            this.Controls.Add(this.btn_Col6Slot);
            this.Controls.Add(this.btn_Col5Slot);
            this.Controls.Add(this.btn_Col4Slot);
            this.Controls.Add(this.btn_Col3Slot);
            this.Controls.Add(this.btn_Col2Slot);
            this.Controls.Add(this.btn_Col1Slot);
            this.Controls.Add(this.btn_Col0Slot);
            this.Controls.Add(this.btn_56);
            this.Controls.Add(this.btn_55);
            this.Controls.Add(this.btn_54);
            this.Controls.Add(this.btn_53);
            this.Controls.Add(this.btn_52);
            this.Controls.Add(this.btn_51);
            this.Controls.Add(this.btn_50);
            this.Controls.Add(this.btn_46);
            this.Controls.Add(this.btn_45);
            this.Controls.Add(this.btn_44);
            this.Controls.Add(this.btn_43);
            this.Controls.Add(this.btn_42);
            this.Controls.Add(this.btn_41);
            this.Controls.Add(this.btn_40);
            this.Controls.Add(this.btn_36);
            this.Controls.Add(this.btn_35);
            this.Controls.Add(this.btn_34);
            this.Controls.Add(this.btn_33);
            this.Controls.Add(this.btn_32);
            this.Controls.Add(this.btn_31);
            this.Controls.Add(this.btn_30);
            this.Controls.Add(this.btn_26);
            this.Controls.Add(this.btn_25);
            this.Controls.Add(this.btn_24);
            this.Controls.Add(this.btn_23);
            this.Controls.Add(this.btn_22);
            this.Controls.Add(this.btn_21);
            this.Controls.Add(this.btn_20);
            this.Controls.Add(this.btn_16);
            this.Controls.Add(this.btn_15);
            this.Controls.Add(this.btn_14);
            this.Controls.Add(this.btn_13);
            this.Controls.Add(this.btn_12);
            this.Controls.Add(this.btn_11);
            this.Controls.Add(this.btn_10);
            this.Controls.Add(this.btn_06);
            this.Controls.Add(this.btn_05);
            this.Controls.Add(this.btn_04);
            this.Controls.Add(this.btn_03);
            this.Controls.Add(this.btn_02);
            this.Controls.Add(this.btn_01);
            this.Controls.Add(this.btn_00);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_loadMainScreen);
            this.Name = "TwoPlayerC4Form";
            this.Text = "TwoPlayerC4Form";
            this.Load += new System.EventHandler(this.TwoPlayerC4Form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Col6Slot;
        private System.Windows.Forms.Button btn_Col5Slot;
        private System.Windows.Forms.Button btn_Col4Slot;
        private System.Windows.Forms.Button btn_Col3Slot;
        private System.Windows.Forms.Button btn_Col2Slot;
        private System.Windows.Forms.Button btn_Col1Slot;
        private System.Windows.Forms.Button btn_Col0Slot;
        private System.Windows.Forms.Button btn_56;
        private System.Windows.Forms.Button btn_55;
        private System.Windows.Forms.Button btn_54;
        private System.Windows.Forms.Button btn_53;
        private System.Windows.Forms.Button btn_52;
        private System.Windows.Forms.Button btn_51;
        private System.Windows.Forms.Button btn_50;
        private System.Windows.Forms.Button btn_46;
        private System.Windows.Forms.Button btn_45;
        private System.Windows.Forms.Button btn_44;
        private System.Windows.Forms.Button btn_43;
        private System.Windows.Forms.Button btn_42;
        private System.Windows.Forms.Button btn_41;
        private System.Windows.Forms.Button btn_40;
        private System.Windows.Forms.Button btn_36;
        private System.Windows.Forms.Button btn_35;
        private System.Windows.Forms.Button btn_34;
        private System.Windows.Forms.Button btn_33;
        private System.Windows.Forms.Button btn_32;
        private System.Windows.Forms.Button btn_31;
        private System.Windows.Forms.Button btn_30;
        private System.Windows.Forms.Button btn_26;
        private System.Windows.Forms.Button btn_25;
        private System.Windows.Forms.Button btn_24;
        private System.Windows.Forms.Button btn_23;
        private System.Windows.Forms.Button btn_22;
        private System.Windows.Forms.Button btn_21;
        private System.Windows.Forms.Button btn_20;
        private System.Windows.Forms.Button btn_16;
        private System.Windows.Forms.Button btn_15;
        private System.Windows.Forms.Button btn_14;
        private System.Windows.Forms.Button btn_13;
        private System.Windows.Forms.Button btn_12;
        private System.Windows.Forms.Button btn_11;
        private System.Windows.Forms.Button btn_10;
        private System.Windows.Forms.Button btn_06;
        private System.Windows.Forms.Button btn_05;
        private System.Windows.Forms.Button btn_04;
        private System.Windows.Forms.Button btn_03;
        private System.Windows.Forms.Button btn_02;
        private System.Windows.Forms.Button btn_01;
        private System.Windows.Forms.Button btn_00;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Button btn_loadMainScreen;
        private System.Windows.Forms.TextBox txt_playerTurn;
    }
}