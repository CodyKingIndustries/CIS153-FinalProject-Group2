﻿namespace CIS153_FinalProject_Group2
{
    partial class SinglePlayerC4Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Exit = new System.Windows.Forms.Button();
            this.btn_SPC4_tempLoadForm = new System.Windows.Forms.Button();
            this.btn_Row1Space6 = new System.Windows.Forms.Button();
            this.btn_Row2Space6 = new System.Windows.Forms.Button();
            this.btn_Row3Space6 = new System.Windows.Forms.Button();
            this.btn_Row4Space6 = new System.Windows.Forms.Button();
            this.btn_Row5Space6 = new System.Windows.Forms.Button();
            this.btn_Row6Space6 = new System.Windows.Forms.Button();
            this.btn_Row7Space6 = new System.Windows.Forms.Button();
            this.btn_Row7Space5 = new System.Windows.Forms.Button();
            this.btn_Row6Space5 = new System.Windows.Forms.Button();
            this.btn_Row5Space5 = new System.Windows.Forms.Button();
            this.btn_Row4Space5 = new System.Windows.Forms.Button();
            this.btn_Row3Space5 = new System.Windows.Forms.Button();
            this.btn_Row2Space5 = new System.Windows.Forms.Button();
            this.btn_Row1Space5 = new System.Windows.Forms.Button();
            this.btn_Row7Space4 = new System.Windows.Forms.Button();
            this.btn_Row6Space4 = new System.Windows.Forms.Button();
            this.btn_Row5Space4 = new System.Windows.Forms.Button();
            this.btn_Row4Space4 = new System.Windows.Forms.Button();
            this.btn_Row3Space4 = new System.Windows.Forms.Button();
            this.btn_Row2Space4 = new System.Windows.Forms.Button();
            this.btn_Row1Space4 = new System.Windows.Forms.Button();
            this.btn_Row7Space3 = new System.Windows.Forms.Button();
            this.btn_Row6Space3 = new System.Windows.Forms.Button();
            this.btn_Row5Space3 = new System.Windows.Forms.Button();
            this.btn_Row4Space3 = new System.Windows.Forms.Button();
            this.btn_Row3Space3 = new System.Windows.Forms.Button();
            this.btn_Row2Space3 = new System.Windows.Forms.Button();
            this.btn_Row1Space3 = new System.Windows.Forms.Button();
            this.btn_Row7Space2 = new System.Windows.Forms.Button();
            this.btn_Row6Space2 = new System.Windows.Forms.Button();
            this.btn_Row5Space2 = new System.Windows.Forms.Button();
            this.btn_Row4Space2 = new System.Windows.Forms.Button();
            this.btn_Row3Space2 = new System.Windows.Forms.Button();
            this.btn_Row2Space2 = new System.Windows.Forms.Button();
            this.btn_Row1Space2 = new System.Windows.Forms.Button();
            this.btn_Row7Space1 = new System.Windows.Forms.Button();
            this.btn_Row6Space1 = new System.Windows.Forms.Button();
            this.btn_Row5Space1 = new System.Windows.Forms.Button();
            this.btn_Row4Space1 = new System.Windows.Forms.Button();
            this.btn_Row3Space1 = new System.Windows.Forms.Button();
            this.btn_Row2Space1 = new System.Windows.Forms.Button();
            this.btn_Row1Space1 = new System.Windows.Forms.Button();
            this.btn_Row1Slot = new System.Windows.Forms.Button();
            this.btn_Row2Slot = new System.Windows.Forms.Button();
            this.btn_Row3Slot = new System.Windows.Forms.Button();
            this.btn_Row4Slot = new System.Windows.Forms.Button();
            this.btn_Row5Slot = new System.Windows.Forms.Button();
            this.btn_Row6Slot = new System.Windows.Forms.Button();
            this.btn_Row7Slot = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Exit
            // 
            this.btn_Exit.BackColor = System.Drawing.Color.Red;
            this.btn_Exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Exit.ForeColor = System.Drawing.Color.White;
            this.btn_Exit.Location = new System.Drawing.Point(299, 485);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(135, 37);
            this.btn_Exit.TabIndex = 1;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = false;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // btn_SPC4_tempLoadForm
            // 
            this.btn_SPC4_tempLoadForm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btn_SPC4_tempLoadForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SPC4_tempLoadForm.ForeColor = System.Drawing.Color.White;
            this.btn_SPC4_tempLoadForm.Location = new System.Drawing.Point(115, 485);
            this.btn_SPC4_tempLoadForm.Name = "btn_SPC4_tempLoadForm";
            this.btn_SPC4_tempLoadForm.Size = new System.Drawing.Size(135, 37);
            this.btn_SPC4_tempLoadForm.TabIndex = 0;
            this.btn_SPC4_tempLoadForm.Text = "Main Screen";
            this.btn_SPC4_tempLoadForm.UseVisualStyleBackColor = false;
            this.btn_SPC4_tempLoadForm.Click += new System.EventHandler(this.btn_SPC4_tempLoadForm_Click);
            // 
            // btn_Row1Space6
            // 
            this.btn_Row1Space6.BackColor = System.Drawing.Color.White;
            this.btn_Row1Space6.Enabled = false;
            this.btn_Row1Space6.Location = new System.Drawing.Point(50, 98);
            this.btn_Row1Space6.Name = "btn_Row1Space6";
            this.btn_Row1Space6.Size = new System.Drawing.Size(59, 59);
            this.btn_Row1Space6.TabIndex = 2;
            this.btn_Row1Space6.UseVisualStyleBackColor = false;
            // 
            // btn_Row2Space6
            // 
            this.btn_Row2Space6.BackColor = System.Drawing.Color.White;
            this.btn_Row2Space6.Enabled = false;
            this.btn_Row2Space6.Location = new System.Drawing.Point(115, 98);
            this.btn_Row2Space6.Name = "btn_Row2Space6";
            this.btn_Row2Space6.Size = new System.Drawing.Size(59, 59);
            this.btn_Row2Space6.TabIndex = 3;
            this.btn_Row2Space6.UseVisualStyleBackColor = false;
            // 
            // btn_Row3Space6
            // 
            this.btn_Row3Space6.BackColor = System.Drawing.Color.White;
            this.btn_Row3Space6.Enabled = false;
            this.btn_Row3Space6.Location = new System.Drawing.Point(180, 98);
            this.btn_Row3Space6.Name = "btn_Row3Space6";
            this.btn_Row3Space6.Size = new System.Drawing.Size(59, 59);
            this.btn_Row3Space6.TabIndex = 4;
            this.btn_Row3Space6.UseVisualStyleBackColor = false;
            // 
            // btn_Row4Space6
            // 
            this.btn_Row4Space6.BackColor = System.Drawing.Color.White;
            this.btn_Row4Space6.Enabled = false;
            this.btn_Row4Space6.Location = new System.Drawing.Point(245, 98);
            this.btn_Row4Space6.Name = "btn_Row4Space6";
            this.btn_Row4Space6.Size = new System.Drawing.Size(59, 59);
            this.btn_Row4Space6.TabIndex = 5;
            this.btn_Row4Space6.UseVisualStyleBackColor = false;
            // 
            // btn_Row5Space6
            // 
            this.btn_Row5Space6.BackColor = System.Drawing.Color.White;
            this.btn_Row5Space6.Enabled = false;
            this.btn_Row5Space6.Location = new System.Drawing.Point(310, 98);
            this.btn_Row5Space6.Name = "btn_Row5Space6";
            this.btn_Row5Space6.Size = new System.Drawing.Size(59, 59);
            this.btn_Row5Space6.TabIndex = 6;
            this.btn_Row5Space6.UseVisualStyleBackColor = false;
            // 
            // btn_Row6Space6
            // 
            this.btn_Row6Space6.BackColor = System.Drawing.Color.White;
            this.btn_Row6Space6.Enabled = false;
            this.btn_Row6Space6.Location = new System.Drawing.Point(375, 98);
            this.btn_Row6Space6.Name = "btn_Row6Space6";
            this.btn_Row6Space6.Size = new System.Drawing.Size(59, 59);
            this.btn_Row6Space6.TabIndex = 7;
            this.btn_Row6Space6.UseVisualStyleBackColor = false;
            // 
            // btn_Row7Space6
            // 
            this.btn_Row7Space6.BackColor = System.Drawing.Color.White;
            this.btn_Row7Space6.Enabled = false;
            this.btn_Row7Space6.Location = new System.Drawing.Point(440, 98);
            this.btn_Row7Space6.Name = "btn_Row7Space6";
            this.btn_Row7Space6.Size = new System.Drawing.Size(59, 59);
            this.btn_Row7Space6.TabIndex = 8;
            this.btn_Row7Space6.UseVisualStyleBackColor = false;
            // 
            // btn_Row7Space5
            // 
            this.btn_Row7Space5.BackColor = System.Drawing.Color.White;
            this.btn_Row7Space5.Enabled = false;
            this.btn_Row7Space5.Location = new System.Drawing.Point(440, 161);
            this.btn_Row7Space5.Name = "btn_Row7Space5";
            this.btn_Row7Space5.Size = new System.Drawing.Size(59, 59);
            this.btn_Row7Space5.TabIndex = 15;
            this.btn_Row7Space5.UseVisualStyleBackColor = false;
            // 
            // btn_Row6Space5
            // 
            this.btn_Row6Space5.BackColor = System.Drawing.Color.White;
            this.btn_Row6Space5.Enabled = false;
            this.btn_Row6Space5.Location = new System.Drawing.Point(375, 161);
            this.btn_Row6Space5.Name = "btn_Row6Space5";
            this.btn_Row6Space5.Size = new System.Drawing.Size(59, 59);
            this.btn_Row6Space5.TabIndex = 14;
            this.btn_Row6Space5.UseVisualStyleBackColor = false;
            // 
            // btn_Row5Space5
            // 
            this.btn_Row5Space5.BackColor = System.Drawing.Color.White;
            this.btn_Row5Space5.Enabled = false;
            this.btn_Row5Space5.Location = new System.Drawing.Point(310, 161);
            this.btn_Row5Space5.Name = "btn_Row5Space5";
            this.btn_Row5Space5.Size = new System.Drawing.Size(59, 59);
            this.btn_Row5Space5.TabIndex = 13;
            this.btn_Row5Space5.UseVisualStyleBackColor = false;
            // 
            // btn_Row4Space5
            // 
            this.btn_Row4Space5.BackColor = System.Drawing.Color.White;
            this.btn_Row4Space5.Enabled = false;
            this.btn_Row4Space5.Location = new System.Drawing.Point(245, 161);
            this.btn_Row4Space5.Name = "btn_Row4Space5";
            this.btn_Row4Space5.Size = new System.Drawing.Size(59, 59);
            this.btn_Row4Space5.TabIndex = 12;
            this.btn_Row4Space5.UseVisualStyleBackColor = false;
            // 
            // btn_Row3Space5
            // 
            this.btn_Row3Space5.BackColor = System.Drawing.Color.White;
            this.btn_Row3Space5.Enabled = false;
            this.btn_Row3Space5.Location = new System.Drawing.Point(180, 161);
            this.btn_Row3Space5.Name = "btn_Row3Space5";
            this.btn_Row3Space5.Size = new System.Drawing.Size(59, 59);
            this.btn_Row3Space5.TabIndex = 11;
            this.btn_Row3Space5.UseVisualStyleBackColor = false;
            // 
            // btn_Row2Space5
            // 
            this.btn_Row2Space5.BackColor = System.Drawing.Color.White;
            this.btn_Row2Space5.Enabled = false;
            this.btn_Row2Space5.Location = new System.Drawing.Point(115, 161);
            this.btn_Row2Space5.Name = "btn_Row2Space5";
            this.btn_Row2Space5.Size = new System.Drawing.Size(59, 59);
            this.btn_Row2Space5.TabIndex = 10;
            this.btn_Row2Space5.UseVisualStyleBackColor = false;
            // 
            // btn_Row1Space5
            // 
            this.btn_Row1Space5.BackColor = System.Drawing.Color.White;
            this.btn_Row1Space5.Enabled = false;
            this.btn_Row1Space5.Location = new System.Drawing.Point(50, 161);
            this.btn_Row1Space5.Name = "btn_Row1Space5";
            this.btn_Row1Space5.Size = new System.Drawing.Size(59, 59);
            this.btn_Row1Space5.TabIndex = 9;
            this.btn_Row1Space5.UseVisualStyleBackColor = false;
            // 
            // btn_Row7Space4
            // 
            this.btn_Row7Space4.BackColor = System.Drawing.Color.White;
            this.btn_Row7Space4.Enabled = false;
            this.btn_Row7Space4.Location = new System.Drawing.Point(440, 224);
            this.btn_Row7Space4.Name = "btn_Row7Space4";
            this.btn_Row7Space4.Size = new System.Drawing.Size(59, 59);
            this.btn_Row7Space4.TabIndex = 22;
            this.btn_Row7Space4.UseVisualStyleBackColor = false;
            // 
            // btn_Row6Space4
            // 
            this.btn_Row6Space4.BackColor = System.Drawing.Color.White;
            this.btn_Row6Space4.Enabled = false;
            this.btn_Row6Space4.Location = new System.Drawing.Point(375, 224);
            this.btn_Row6Space4.Name = "btn_Row6Space4";
            this.btn_Row6Space4.Size = new System.Drawing.Size(59, 59);
            this.btn_Row6Space4.TabIndex = 21;
            this.btn_Row6Space4.UseVisualStyleBackColor = false;
            // 
            // btn_Row5Space4
            // 
            this.btn_Row5Space4.BackColor = System.Drawing.Color.White;
            this.btn_Row5Space4.Enabled = false;
            this.btn_Row5Space4.Location = new System.Drawing.Point(310, 224);
            this.btn_Row5Space4.Name = "btn_Row5Space4";
            this.btn_Row5Space4.Size = new System.Drawing.Size(59, 59);
            this.btn_Row5Space4.TabIndex = 20;
            this.btn_Row5Space4.UseVisualStyleBackColor = false;
            // 
            // btn_Row4Space4
            // 
            this.btn_Row4Space4.BackColor = System.Drawing.Color.White;
            this.btn_Row4Space4.Enabled = false;
            this.btn_Row4Space4.Location = new System.Drawing.Point(245, 224);
            this.btn_Row4Space4.Name = "btn_Row4Space4";
            this.btn_Row4Space4.Size = new System.Drawing.Size(59, 59);
            this.btn_Row4Space4.TabIndex = 19;
            this.btn_Row4Space4.UseVisualStyleBackColor = false;
            // 
            // btn_Row3Space4
            // 
            this.btn_Row3Space4.BackColor = System.Drawing.Color.White;
            this.btn_Row3Space4.Enabled = false;
            this.btn_Row3Space4.Location = new System.Drawing.Point(180, 224);
            this.btn_Row3Space4.Name = "btn_Row3Space4";
            this.btn_Row3Space4.Size = new System.Drawing.Size(59, 59);
            this.btn_Row3Space4.TabIndex = 18;
            this.btn_Row3Space4.UseVisualStyleBackColor = false;
            // 
            // btn_Row2Space4
            // 
            this.btn_Row2Space4.BackColor = System.Drawing.Color.White;
            this.btn_Row2Space4.Enabled = false;
            this.btn_Row2Space4.Location = new System.Drawing.Point(115, 224);
            this.btn_Row2Space4.Name = "btn_Row2Space4";
            this.btn_Row2Space4.Size = new System.Drawing.Size(59, 59);
            this.btn_Row2Space4.TabIndex = 17;
            this.btn_Row2Space4.UseVisualStyleBackColor = false;
            // 
            // btn_Row1Space4
            // 
            this.btn_Row1Space4.BackColor = System.Drawing.Color.White;
            this.btn_Row1Space4.Enabled = false;
            this.btn_Row1Space4.Location = new System.Drawing.Point(50, 224);
            this.btn_Row1Space4.Name = "btn_Row1Space4";
            this.btn_Row1Space4.Size = new System.Drawing.Size(59, 59);
            this.btn_Row1Space4.TabIndex = 16;
            this.btn_Row1Space4.UseVisualStyleBackColor = false;
            // 
            // btn_Row7Space3
            // 
            this.btn_Row7Space3.BackColor = System.Drawing.Color.White;
            this.btn_Row7Space3.Enabled = false;
            this.btn_Row7Space3.Location = new System.Drawing.Point(440, 287);
            this.btn_Row7Space3.Name = "btn_Row7Space3";
            this.btn_Row7Space3.Size = new System.Drawing.Size(59, 59);
            this.btn_Row7Space3.TabIndex = 29;
            this.btn_Row7Space3.UseVisualStyleBackColor = false;
            // 
            // btn_Row6Space3
            // 
            this.btn_Row6Space3.BackColor = System.Drawing.Color.White;
            this.btn_Row6Space3.Enabled = false;
            this.btn_Row6Space3.Location = new System.Drawing.Point(375, 287);
            this.btn_Row6Space3.Name = "btn_Row6Space3";
            this.btn_Row6Space3.Size = new System.Drawing.Size(59, 59);
            this.btn_Row6Space3.TabIndex = 28;
            this.btn_Row6Space3.UseVisualStyleBackColor = false;
            // 
            // btn_Row5Space3
            // 
            this.btn_Row5Space3.BackColor = System.Drawing.Color.White;
            this.btn_Row5Space3.Enabled = false;
            this.btn_Row5Space3.Location = new System.Drawing.Point(310, 287);
            this.btn_Row5Space3.Name = "btn_Row5Space3";
            this.btn_Row5Space3.Size = new System.Drawing.Size(59, 59);
            this.btn_Row5Space3.TabIndex = 27;
            this.btn_Row5Space3.UseVisualStyleBackColor = false;
            // 
            // btn_Row4Space3
            // 
            this.btn_Row4Space3.BackColor = System.Drawing.Color.White;
            this.btn_Row4Space3.Enabled = false;
            this.btn_Row4Space3.Location = new System.Drawing.Point(245, 287);
            this.btn_Row4Space3.Name = "btn_Row4Space3";
            this.btn_Row4Space3.Size = new System.Drawing.Size(59, 59);
            this.btn_Row4Space3.TabIndex = 26;
            this.btn_Row4Space3.UseVisualStyleBackColor = false;
            // 
            // btn_Row3Space3
            // 
            this.btn_Row3Space3.BackColor = System.Drawing.Color.White;
            this.btn_Row3Space3.Enabled = false;
            this.btn_Row3Space3.Location = new System.Drawing.Point(180, 287);
            this.btn_Row3Space3.Name = "btn_Row3Space3";
            this.btn_Row3Space3.Size = new System.Drawing.Size(59, 59);
            this.btn_Row3Space3.TabIndex = 25;
            this.btn_Row3Space3.UseVisualStyleBackColor = false;
            // 
            // btn_Row2Space3
            // 
            this.btn_Row2Space3.BackColor = System.Drawing.Color.White;
            this.btn_Row2Space3.Enabled = false;
            this.btn_Row2Space3.Location = new System.Drawing.Point(115, 287);
            this.btn_Row2Space3.Name = "btn_Row2Space3";
            this.btn_Row2Space3.Size = new System.Drawing.Size(59, 59);
            this.btn_Row2Space3.TabIndex = 24;
            this.btn_Row2Space3.UseVisualStyleBackColor = false;
            // 
            // btn_Row1Space3
            // 
            this.btn_Row1Space3.BackColor = System.Drawing.Color.White;
            this.btn_Row1Space3.Enabled = false;
            this.btn_Row1Space3.Location = new System.Drawing.Point(50, 287);
            this.btn_Row1Space3.Name = "btn_Row1Space3";
            this.btn_Row1Space3.Size = new System.Drawing.Size(59, 59);
            this.btn_Row1Space3.TabIndex = 23;
            this.btn_Row1Space3.UseVisualStyleBackColor = false;
            // 
            // btn_Row7Space2
            // 
            this.btn_Row7Space2.BackColor = System.Drawing.Color.White;
            this.btn_Row7Space2.Enabled = false;
            this.btn_Row7Space2.Location = new System.Drawing.Point(440, 350);
            this.btn_Row7Space2.Name = "btn_Row7Space2";
            this.btn_Row7Space2.Size = new System.Drawing.Size(59, 59);
            this.btn_Row7Space2.TabIndex = 36;
            this.btn_Row7Space2.UseVisualStyleBackColor = false;
            // 
            // btn_Row6Space2
            // 
            this.btn_Row6Space2.BackColor = System.Drawing.Color.White;
            this.btn_Row6Space2.Enabled = false;
            this.btn_Row6Space2.Location = new System.Drawing.Point(375, 350);
            this.btn_Row6Space2.Name = "btn_Row6Space2";
            this.btn_Row6Space2.Size = new System.Drawing.Size(59, 59);
            this.btn_Row6Space2.TabIndex = 35;
            this.btn_Row6Space2.UseVisualStyleBackColor = false;
            // 
            // btn_Row5Space2
            // 
            this.btn_Row5Space2.BackColor = System.Drawing.Color.White;
            this.btn_Row5Space2.Enabled = false;
            this.btn_Row5Space2.Location = new System.Drawing.Point(310, 350);
            this.btn_Row5Space2.Name = "btn_Row5Space2";
            this.btn_Row5Space2.Size = new System.Drawing.Size(59, 59);
            this.btn_Row5Space2.TabIndex = 34;
            this.btn_Row5Space2.UseVisualStyleBackColor = false;
            // 
            // btn_Row4Space2
            // 
            this.btn_Row4Space2.BackColor = System.Drawing.Color.White;
            this.btn_Row4Space2.Enabled = false;
            this.btn_Row4Space2.Location = new System.Drawing.Point(245, 350);
            this.btn_Row4Space2.Name = "btn_Row4Space2";
            this.btn_Row4Space2.Size = new System.Drawing.Size(59, 59);
            this.btn_Row4Space2.TabIndex = 33;
            this.btn_Row4Space2.UseVisualStyleBackColor = false;
            // 
            // btn_Row3Space2
            // 
            this.btn_Row3Space2.BackColor = System.Drawing.Color.White;
            this.btn_Row3Space2.Enabled = false;
            this.btn_Row3Space2.Location = new System.Drawing.Point(180, 350);
            this.btn_Row3Space2.Name = "btn_Row3Space2";
            this.btn_Row3Space2.Size = new System.Drawing.Size(59, 59);
            this.btn_Row3Space2.TabIndex = 32;
            this.btn_Row3Space2.UseVisualStyleBackColor = false;
            // 
            // btn_Row2Space2
            // 
            this.btn_Row2Space2.BackColor = System.Drawing.Color.White;
            this.btn_Row2Space2.Enabled = false;
            this.btn_Row2Space2.Location = new System.Drawing.Point(115, 350);
            this.btn_Row2Space2.Name = "btn_Row2Space2";
            this.btn_Row2Space2.Size = new System.Drawing.Size(59, 59);
            this.btn_Row2Space2.TabIndex = 31;
            this.btn_Row2Space2.UseVisualStyleBackColor = false;
            // 
            // btn_Row1Space2
            // 
            this.btn_Row1Space2.BackColor = System.Drawing.Color.White;
            this.btn_Row1Space2.Enabled = false;
            this.btn_Row1Space2.Location = new System.Drawing.Point(50, 350);
            this.btn_Row1Space2.Name = "btn_Row1Space2";
            this.btn_Row1Space2.Size = new System.Drawing.Size(59, 59);
            this.btn_Row1Space2.TabIndex = 30;
            this.btn_Row1Space2.UseVisualStyleBackColor = false;
            // 
            // btn_Row7Space1
            // 
            this.btn_Row7Space1.BackColor = System.Drawing.Color.White;
            this.btn_Row7Space1.Enabled = false;
            this.btn_Row7Space1.Location = new System.Drawing.Point(440, 413);
            this.btn_Row7Space1.Name = "btn_Row7Space1";
            this.btn_Row7Space1.Size = new System.Drawing.Size(59, 59);
            this.btn_Row7Space1.TabIndex = 43;
            this.btn_Row7Space1.UseVisualStyleBackColor = false;
            // 
            // btn_Row6Space1
            // 
            this.btn_Row6Space1.BackColor = System.Drawing.Color.White;
            this.btn_Row6Space1.Enabled = false;
            this.btn_Row6Space1.Location = new System.Drawing.Point(375, 413);
            this.btn_Row6Space1.Name = "btn_Row6Space1";
            this.btn_Row6Space1.Size = new System.Drawing.Size(59, 59);
            this.btn_Row6Space1.TabIndex = 42;
            this.btn_Row6Space1.UseVisualStyleBackColor = false;
            // 
            // btn_Row5Space1
            // 
            this.btn_Row5Space1.BackColor = System.Drawing.Color.White;
            this.btn_Row5Space1.Enabled = false;
            this.btn_Row5Space1.Location = new System.Drawing.Point(310, 413);
            this.btn_Row5Space1.Name = "btn_Row5Space1";
            this.btn_Row5Space1.Size = new System.Drawing.Size(59, 59);
            this.btn_Row5Space1.TabIndex = 41;
            this.btn_Row5Space1.UseVisualStyleBackColor = false;
            // 
            // btn_Row4Space1
            // 
            this.btn_Row4Space1.BackColor = System.Drawing.Color.White;
            this.btn_Row4Space1.Enabled = false;
            this.btn_Row4Space1.Location = new System.Drawing.Point(245, 413);
            this.btn_Row4Space1.Name = "btn_Row4Space1";
            this.btn_Row4Space1.Size = new System.Drawing.Size(59, 59);
            this.btn_Row4Space1.TabIndex = 40;
            this.btn_Row4Space1.UseVisualStyleBackColor = false;
            // 
            // btn_Row3Space1
            // 
            this.btn_Row3Space1.BackColor = System.Drawing.Color.White;
            this.btn_Row3Space1.Enabled = false;
            this.btn_Row3Space1.Location = new System.Drawing.Point(180, 413);
            this.btn_Row3Space1.Name = "btn_Row3Space1";
            this.btn_Row3Space1.Size = new System.Drawing.Size(59, 59);
            this.btn_Row3Space1.TabIndex = 39;
            this.btn_Row3Space1.UseVisualStyleBackColor = false;
            // 
            // btn_Row2Space1
            // 
            this.btn_Row2Space1.BackColor = System.Drawing.Color.White;
            this.btn_Row2Space1.Enabled = false;
            this.btn_Row2Space1.Location = new System.Drawing.Point(115, 413);
            this.btn_Row2Space1.Name = "btn_Row2Space1";
            this.btn_Row2Space1.Size = new System.Drawing.Size(59, 59);
            this.btn_Row2Space1.TabIndex = 38;
            this.btn_Row2Space1.UseVisualStyleBackColor = false;
            // 
            // btn_Row1Space1
            // 
            this.btn_Row1Space1.BackColor = System.Drawing.Color.White;
            this.btn_Row1Space1.Enabled = false;
            this.btn_Row1Space1.Location = new System.Drawing.Point(50, 413);
            this.btn_Row1Space1.Name = "btn_Row1Space1";
            this.btn_Row1Space1.Size = new System.Drawing.Size(59, 59);
            this.btn_Row1Space1.TabIndex = 37;
            this.btn_Row1Space1.UseVisualStyleBackColor = false;
            // 
            // btn_Row1Slot
            // 
            this.btn_Row1Slot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_Row1Slot.Location = new System.Drawing.Point(50, 33);
            this.btn_Row1Slot.Name = "btn_Row1Slot";
            this.btn_Row1Slot.Size = new System.Drawing.Size(59, 59);
            this.btn_Row1Slot.TabIndex = 44;
            this.btn_Row1Slot.UseVisualStyleBackColor = false;
            this.btn_Row1Slot.Click += new System.EventHandler(this.btn_Row1Slot_Click);
            this.btn_Row1Slot.MouseLeave += new System.EventHandler(this.btn_Row1Slot_MouseLeave);
            this.btn_Row1Slot.MouseHover += new System.EventHandler(this.btn_Row1Slot_MouseHover);
            // 
            // btn_Row2Slot
            // 
            this.btn_Row2Slot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_Row2Slot.Location = new System.Drawing.Point(115, 33);
            this.btn_Row2Slot.Name = "btn_Row2Slot";
            this.btn_Row2Slot.Size = new System.Drawing.Size(59, 59);
            this.btn_Row2Slot.TabIndex = 45;
            this.btn_Row2Slot.UseVisualStyleBackColor = false;
            this.btn_Row2Slot.Click += new System.EventHandler(this.btn_Row2Slot_Click);
            this.btn_Row2Slot.MouseLeave += new System.EventHandler(this.btn_Row2Slot_MouseLeave);
            this.btn_Row2Slot.MouseHover += new System.EventHandler(this.btn_Row2Slot_MouseHover);
            // 
            // btn_Row3Slot
            // 
            this.btn_Row3Slot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_Row3Slot.Location = new System.Drawing.Point(180, 33);
            this.btn_Row3Slot.Name = "btn_Row3Slot";
            this.btn_Row3Slot.Size = new System.Drawing.Size(59, 59);
            this.btn_Row3Slot.TabIndex = 46;
            this.btn_Row3Slot.UseVisualStyleBackColor = false;
            this.btn_Row3Slot.Click += new System.EventHandler(this.btn_Row3Slot_Click);
            this.btn_Row3Slot.MouseLeave += new System.EventHandler(this.btn_Row3Slot_MouseLeave);
            this.btn_Row3Slot.MouseHover += new System.EventHandler(this.btn_Row3Slot_MouseHover);
            // 
            // btn_Row4Slot
            // 
            this.btn_Row4Slot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_Row4Slot.Location = new System.Drawing.Point(245, 33);
            this.btn_Row4Slot.Name = "btn_Row4Slot";
            this.btn_Row4Slot.Size = new System.Drawing.Size(59, 59);
            this.btn_Row4Slot.TabIndex = 47;
            this.btn_Row4Slot.UseVisualStyleBackColor = false;
            this.btn_Row4Slot.Click += new System.EventHandler(this.btn_Row4Slot_Click);
            this.btn_Row4Slot.MouseLeave += new System.EventHandler(this.btn_Row4Slot_MouseLeave);
            this.btn_Row4Slot.MouseHover += new System.EventHandler(this.btn_Row4Slot_MouseHover);
            // 
            // btn_Row5Slot
            // 
            this.btn_Row5Slot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_Row5Slot.Location = new System.Drawing.Point(310, 33);
            this.btn_Row5Slot.Name = "btn_Row5Slot";
            this.btn_Row5Slot.Size = new System.Drawing.Size(59, 59);
            this.btn_Row5Slot.TabIndex = 48;
            this.btn_Row5Slot.UseVisualStyleBackColor = false;
            this.btn_Row5Slot.Click += new System.EventHandler(this.btn_Row5Slot_Click);
            this.btn_Row5Slot.MouseLeave += new System.EventHandler(this.btn_Row5Slot_MouseLeave);
            this.btn_Row5Slot.MouseHover += new System.EventHandler(this.btn_Row5Slot_MouseHover);
            // 
            // btn_Row6Slot
            // 
            this.btn_Row6Slot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_Row6Slot.Location = new System.Drawing.Point(375, 33);
            this.btn_Row6Slot.Name = "btn_Row6Slot";
            this.btn_Row6Slot.Size = new System.Drawing.Size(59, 59);
            this.btn_Row6Slot.TabIndex = 49;
            this.btn_Row6Slot.UseVisualStyleBackColor = false;
            this.btn_Row6Slot.Click += new System.EventHandler(this.btn_Row6Slot_Click);
            this.btn_Row6Slot.MouseLeave += new System.EventHandler(this.btn_Row6Slot_MouseLeave);
            this.btn_Row6Slot.MouseHover += new System.EventHandler(this.btn_Row6Slot_MouseHover);
            // 
            // btn_Row7Slot
            // 
            this.btn_Row7Slot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_Row7Slot.Location = new System.Drawing.Point(440, 33);
            this.btn_Row7Slot.Name = "btn_Row7Slot";
            this.btn_Row7Slot.Size = new System.Drawing.Size(59, 59);
            this.btn_Row7Slot.TabIndex = 50;
            this.btn_Row7Slot.UseVisualStyleBackColor = false;
            this.btn_Row7Slot.Click += new System.EventHandler(this.btn_Row7Slot_Click);
            this.btn_Row7Slot.MouseLeave += new System.EventHandler(this.btn_Row7Slot_MouseLeave);
            this.btn_Row7Slot.MouseHover += new System.EventHandler(this.btn_Row7Slot_MouseHover);
            // 
            // SinglePlayerC4Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.ClientSize = new System.Drawing.Size(543, 535);
            this.Controls.Add(this.btn_Row7Slot);
            this.Controls.Add(this.btn_Row6Slot);
            this.Controls.Add(this.btn_Row5Slot);
            this.Controls.Add(this.btn_Row4Slot);
            this.Controls.Add(this.btn_Row3Slot);
            this.Controls.Add(this.btn_Row2Slot);
            this.Controls.Add(this.btn_Row1Slot);
            this.Controls.Add(this.btn_Row7Space1);
            this.Controls.Add(this.btn_Row6Space1);
            this.Controls.Add(this.btn_Row5Space1);
            this.Controls.Add(this.btn_Row4Space1);
            this.Controls.Add(this.btn_Row3Space1);
            this.Controls.Add(this.btn_Row2Space1);
            this.Controls.Add(this.btn_Row1Space1);
            this.Controls.Add(this.btn_Row7Space2);
            this.Controls.Add(this.btn_Row6Space2);
            this.Controls.Add(this.btn_Row5Space2);
            this.Controls.Add(this.btn_Row4Space2);
            this.Controls.Add(this.btn_Row3Space2);
            this.Controls.Add(this.btn_Row2Space2);
            this.Controls.Add(this.btn_Row1Space2);
            this.Controls.Add(this.btn_Row7Space3);
            this.Controls.Add(this.btn_Row6Space3);
            this.Controls.Add(this.btn_Row5Space3);
            this.Controls.Add(this.btn_Row4Space3);
            this.Controls.Add(this.btn_Row3Space3);
            this.Controls.Add(this.btn_Row2Space3);
            this.Controls.Add(this.btn_Row1Space3);
            this.Controls.Add(this.btn_Row7Space4);
            this.Controls.Add(this.btn_Row6Space4);
            this.Controls.Add(this.btn_Row5Space4);
            this.Controls.Add(this.btn_Row4Space4);
            this.Controls.Add(this.btn_Row3Space4);
            this.Controls.Add(this.btn_Row2Space4);
            this.Controls.Add(this.btn_Row1Space4);
            this.Controls.Add(this.btn_Row7Space5);
            this.Controls.Add(this.btn_Row6Space5);
            this.Controls.Add(this.btn_Row5Space5);
            this.Controls.Add(this.btn_Row4Space5);
            this.Controls.Add(this.btn_Row3Space5);
            this.Controls.Add(this.btn_Row2Space5);
            this.Controls.Add(this.btn_Row1Space5);
            this.Controls.Add(this.btn_Row7Space6);
            this.Controls.Add(this.btn_Row6Space6);
            this.Controls.Add(this.btn_Row5Space6);
            this.Controls.Add(this.btn_Row4Space6);
            this.Controls.Add(this.btn_Row3Space6);
            this.Controls.Add(this.btn_Row2Space6);
            this.Controls.Add(this.btn_Row1Space6);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_SPC4_tempLoadForm);
            this.Name = "SinglePlayerC4Form";
            this.Text = "SinglePlayerC4Form";
            this.Load += new System.EventHandler(this.SinglePlayerC4Form_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Button btn_SPC4_tempLoadForm;
        private System.Windows.Forms.Button btn_Row1Space6;
        private System.Windows.Forms.Button btn_Row2Space6;
        private System.Windows.Forms.Button btn_Row3Space6;
        private System.Windows.Forms.Button btn_Row4Space6;
        private System.Windows.Forms.Button btn_Row5Space6;
        private System.Windows.Forms.Button btn_Row6Space6;
        private System.Windows.Forms.Button btn_Row7Space6;
        private System.Windows.Forms.Button btn_Row7Space5;
        private System.Windows.Forms.Button btn_Row6Space5;
        private System.Windows.Forms.Button btn_Row5Space5;
        private System.Windows.Forms.Button btn_Row4Space5;
        private System.Windows.Forms.Button btn_Row3Space5;
        private System.Windows.Forms.Button btn_Row2Space5;
        private System.Windows.Forms.Button btn_Row1Space5;
        private System.Windows.Forms.Button btn_Row7Space4;
        private System.Windows.Forms.Button btn_Row6Space4;
        private System.Windows.Forms.Button btn_Row5Space4;
        private System.Windows.Forms.Button btn_Row4Space4;
        private System.Windows.Forms.Button btn_Row3Space4;
        private System.Windows.Forms.Button btn_Row2Space4;
        private System.Windows.Forms.Button btn_Row1Space4;
        private System.Windows.Forms.Button btn_Row7Space3;
        private System.Windows.Forms.Button btn_Row6Space3;
        private System.Windows.Forms.Button btn_Row5Space3;
        private System.Windows.Forms.Button btn_Row4Space3;
        private System.Windows.Forms.Button btn_Row3Space3;
        private System.Windows.Forms.Button btn_Row2Space3;
        private System.Windows.Forms.Button btn_Row1Space3;
        private System.Windows.Forms.Button btn_Row7Space2;
        private System.Windows.Forms.Button btn_Row6Space2;
        private System.Windows.Forms.Button btn_Row5Space2;
        private System.Windows.Forms.Button btn_Row4Space2;
        private System.Windows.Forms.Button btn_Row3Space2;
        private System.Windows.Forms.Button btn_Row2Space2;
        private System.Windows.Forms.Button btn_Row1Space2;
        private System.Windows.Forms.Button btn_Row7Space1;
        private System.Windows.Forms.Button btn_Row6Space1;
        private System.Windows.Forms.Button btn_Row5Space1;
        private System.Windows.Forms.Button btn_Row4Space1;
        private System.Windows.Forms.Button btn_Row3Space1;
        private System.Windows.Forms.Button btn_Row2Space1;
        private System.Windows.Forms.Button btn_Row1Space1;
        private System.Windows.Forms.Button btn_Row1Slot;
        private System.Windows.Forms.Button btn_Row2Slot;
        private System.Windows.Forms.Button btn_Row3Slot;
        private System.Windows.Forms.Button btn_Row4Slot;
        private System.Windows.Forms.Button btn_Row5Slot;
        private System.Windows.Forms.Button btn_Row6Slot;
        private System.Windows.Forms.Button btn_Row7Slot;
    }
}